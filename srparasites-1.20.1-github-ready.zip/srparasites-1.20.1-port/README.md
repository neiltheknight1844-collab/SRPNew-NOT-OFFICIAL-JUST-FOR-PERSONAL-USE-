# Scape and Run: Parasites — Personal Port (Forge 1.20.1)

This repository is a **personal-use** Forge 1.20.1 workspace intended for porting **SRP** with creator permission.

## What works right now
- Project loads on **Minecraft 1.20.1 + Forge 47.x**
- Modern `mods.toml` metadata
- SRP resource assets staged under:
  - `src/main/resources/assets/srparasites/...`
  - `src/main/resources/data/srparasites/...` (legacy recipes/loot/structures were moved here and may need format updates)

> Note: Gameplay logic (entities, AI, worldgen, infection systems) still needs actual API-porting work from 1.12 -> 1.20.1.

## Build a jar locally
**Requires Java 17 and Gradle** (IntelliJ can manage this automatically).

```bash
gradle build
```

Your jar will be in:
```
build/libs/
```

## Run the dev client
```bash
gradle runClient
```

## GitHub Actions build
This repo includes a workflow at `.github/workflows/build.yml` that builds on every push/PR and uploads the built jar as an artifact.

## Repo layout
- `src/main/java/...` — ported code (currently a minimal Forge mod skeleton)
- `src/main/resources/assets/...` — textures, models, blockstates, sounds, lang
- `src/main/resources/data/...` — recipes, loot tables, structures
