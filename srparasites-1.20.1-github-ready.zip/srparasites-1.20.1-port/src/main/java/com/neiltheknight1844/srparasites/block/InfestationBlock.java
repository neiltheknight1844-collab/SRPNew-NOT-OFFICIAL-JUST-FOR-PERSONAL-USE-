package com.neiltheknight1844.srparasites.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

public class InfestationBlock extends Block {
    public InfestationBlock(BlockBehaviour.Properties props) {
        super(props);
    }
}
