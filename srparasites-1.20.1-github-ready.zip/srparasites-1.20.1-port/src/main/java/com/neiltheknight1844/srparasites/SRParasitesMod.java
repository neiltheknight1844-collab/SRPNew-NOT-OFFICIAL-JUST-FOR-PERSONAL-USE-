package com.neiltheknight1844.srparasites;

import com.neiltheknight1844.srparasites.registry.ModBlocks;
import com.neiltheknight1844.srparasites.registry.ModEntities;
import com.neiltheknight1844.srparasites.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(SRParasitesMod.MODID)
public class SRParasitesMod {
    public static final String MODID = "srparasites";

    public SRParasitesMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITIES.register(modBus);

        // TODO: As we port SRP systems, hook them here (configs, networking, capabilities, etc.).
    }
}
