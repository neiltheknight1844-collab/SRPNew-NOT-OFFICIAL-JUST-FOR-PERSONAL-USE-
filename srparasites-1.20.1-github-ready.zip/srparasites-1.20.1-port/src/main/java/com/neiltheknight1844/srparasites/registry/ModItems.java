package com.neiltheknight1844.srparasites.registry;

import com.neiltheknight1844.srparasites.SRParasitesMod;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SRParasitesMod.MODID);

    public static final RegistryObject<Item> INFESTATION_ITEM = ITEMS.register("infestation",
            () -> new BlockItem(ModBlocks.INFESTATION.get(), new Item.Properties()));

    public static final RegistryObject<Item> PARASITE_SPAWN_EGG = ITEMS.register("parasite_spawn_egg",
            () -> new SpawnEggItem(ModEntities.SRP_BASIC, 0x4b2b2b, 0x9f2e2e, new Item.Properties()));
}
