package com.neiltheknight1844.srparasites.registry;

import com.neiltheknight1844.srparasites.SRParasitesMod;
import com.neiltheknight1844.srparasites.entity.SrpBasicMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SRParasitesMod.MODID);

    public static final RegistryObject<EntityType<SrpBasicMob>> SRP_BASIC = ENTITIES.register("srp_basic",
            () -> EntityType.Builder.of(SrpBasicMob::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F)
                    .build(SRParasitesMod.MODID + ":srp_basic"));
}
