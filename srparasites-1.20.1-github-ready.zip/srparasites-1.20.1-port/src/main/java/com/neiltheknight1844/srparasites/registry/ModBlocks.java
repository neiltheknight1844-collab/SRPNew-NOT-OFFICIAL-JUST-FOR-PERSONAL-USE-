package com.neiltheknight1844.srparasites.registry;

import com.neiltheknight1844.srparasites.SRParasitesMod;
import com.neiltheknight1844.srparasites.block.InfestationBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, SRParasitesMod.MODID);

    public static final RegistryObject<Block> INFESTATION = BLOCKS.register("infestation",
            () -> new InfestationBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(1.0F)));
}
