package com.neiltheknight1844.srparasites.client;

import com.neiltheknight1844.srparasites.SRParasitesMod;
import com.neiltheknight1844.srparasites.registry.ModEntities;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.model.ZombieModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SRParasitesMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {

    private static final ResourceLocation TEXTURE = new ResourceLocation(SRParasitesMod.MODID, "textures/entity/srp_basic.png");

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.SRP_BASIC.get(), (EntityRendererProvider.Context ctx) ->
                new HumanoidMobRenderer<>(ctx, new ZombieModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.5F) {
                    @Override
                    public ResourceLocation getTextureLocation(net.minecraft.world.entity.Mob entity) {
                        return TEXTURE;
                    }
                }
        );
    }
}
