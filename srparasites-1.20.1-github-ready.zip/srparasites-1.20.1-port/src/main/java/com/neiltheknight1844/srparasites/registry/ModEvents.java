package com.neiltheknight1844.srparasites.registry;

import com.neiltheknight1844.srparasites.SRParasitesMod;
import com.neiltheknight1844.srparasites.entity.SrpBasicMob;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SRParasitesMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {
    @SubscribeEvent
    public static void onEntityAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.SRP_BASIC.get(), SrpBasicMob.createAttributes().build());
    }
}
